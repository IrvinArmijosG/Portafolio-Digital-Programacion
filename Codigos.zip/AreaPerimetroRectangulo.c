#include <stdio.h>
int main() {
float base, altura, area, perimetro;

// Datos de entrada

printf("Ingrese la base del rectangulo: ");
scanf("%f", &base);
printf("Ingrese la altura del rectangulo: ");
scanf("%f", &altura);

//⚙️ Proceso

area = base * altura;
perimetro = 2 * (base + altura);

//📤 Salida

printf("El area del rectangulo es: %.2f\n", area);
printf("El perimetro del rectangulo es: %.2f\n", perimetro);
return 0;
}